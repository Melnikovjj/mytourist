import { PrismaClient } from '@prisma/client';
const prisma = new PrismaClient();
async function main() {
  const users = await prisma.user.findMany({ select: { id: true, username: true, firstName: true, isOnboarded: true } });
  console.table(users);
}
main().catch(console.error).finally(() => prisma.$disconnect());
