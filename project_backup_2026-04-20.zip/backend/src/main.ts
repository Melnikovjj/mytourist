import * as crypto from 'crypto';
if (!globalThis.crypto) {
    (globalThis as any).crypto = crypto.webcrypto;
}

import { NestFactory } from '@nestjs/core';
import { ValidationPipe } from '@nestjs/common';
import { SwaggerModule, DocumentBuilder } from '@nestjs/swagger';
import { AppModule } from './app.module';

async function bootstrap() {
    console.log('Starting bootstrap...');
    try {
        const app = await NestFactory.create(AppModule);
        console.log('Nest application created.');

        app.setGlobalPrefix('api');
        app.enableCors({
            origin: (origin, callback) => {
                console.log('Incoming request from origin:', origin);
                if (!origin) return callback(null, true);

                const allowedOrigins = [
                    'https://web.telegram.org',
                    'http://localhost:3000',
                    'http://localhost:5173'
                ];

                // Allow Vercel deployments
                if (origin.endsWith('.vercel.app')) return callback(null, true);

                // Allow known origins
                if (allowedOrigins.includes(origin)) return callback(null, true);

                // Allow specific frontend
                if (origin === 'https://frontend-three-sandy-65.vercel.app') return callback(null, true);

                console.log('Allowed context-aware origin:', origin);
                callback(null, true);
            },
            methods: 'GET,HEAD,PUT,PATCH,POST,DELETE,OPTIONS',
            credentials: true,
        });

        app.useGlobalPipes(
            new ValidationPipe({
                whitelist: true,
                forbidNonWhitelisted: false,
                transform: true,
            }),
        );

        const config = new DocumentBuilder()
            .setTitle('Походный Сборщик API')
            .setDescription('Hiking Planner API')
            .setVersion('1.0')
            .addBearerAuth()
            .build();
        const document = SwaggerModule.createDocument(app, config);
        SwaggerModule.setup('api/docs', app, document);

        const port = process.env.PORT || 8080;
        console.log(`🚀 Attempting to listen on port ${port}...`);
        await app.listen(port, '0.0.0.0');
        console.log(`✅ Server is now listening on 0.0.0.0:${port}`);
    } catch (error) {
        console.error('❌ Error starting NestJS application:', error);
        process.exit(1);
    }
}

bootstrap();
