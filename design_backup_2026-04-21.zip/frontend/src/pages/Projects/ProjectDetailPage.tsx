import { useEffect, useState, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowLeft, ShareNetwork, Trash, Gear, ForkKnife, CheckSquare, Users, Calendar, ChatTeardropText, PencilSimple, BookBookmark, Notebook, FirstAid } from '@phosphor-icons/react';
import { useProjectStore } from '../../store/projectStore';
import { useAuthStore } from '../../store/authStore';
import { GlassCard } from '../../components/ui/GlassCard';
import { Button } from '../../components/ui/Button';
import { Badge } from '../../components/ui/Badge';
import { GearTab } from './Tabs/GearTab';
import { FoodTab } from './Tabs/FoodTab';
import { ChecklistTab } from './Tabs/ChecklistTab';
import { ChatTab } from './Tabs/ChatTab';
import { CalendarTab } from './Tabs/CalendarTab';
import { ParticipantsTab } from './Tabs/ParticipantsTab';
import { GuideTab } from './Tabs/GuideTab';
import { DiaryTab } from './Tabs/DiaryTab';
import { MedicineTab } from './Tabs/MedicineTab';
import api from '../../api/client';
import { getSocket } from '../../api/socket';
import type { Message } from '../../types';

type TabType = 'gear' | 'food' | 'checklist' | 'chat' | 'calendar' | 'participants' | 'guide' | 'diary' | 'medicine';

export function ProjectDetailPage() {
    const { projectId } = useParams<{ projectId: string }>();
    const { currentProject, fetchProject, deleteProject } = useProjectStore();
    const { user } = useAuthStore();
    const navigate = useNavigate();
    const [activeTab, setActiveTab] = useState<TabType>('gear');
    const [showEdit, setShowEdit] = useState(false);
    const [editForm, setEditForm] = useState({ title: '', description: '', startDate: '', endDate: '' });
    const [unreadCount, setUnreadCount] = useState(0);

    const activeTabRef = useRef(activeTab);
    useEffect(() => {
        activeTabRef.current = activeTab;
        if (activeTab === 'chat') setUnreadCount(0);
    }, [activeTab]);

    useEffect(() => {
        if (projectId) fetchProject(projectId);
    }, [projectId]);

    useEffect(() => {
        if (projectId && user) {
            const socket = getSocket();
            socket.emit('join_project', { projectId, userId: user.id });

            const handleNewMessage = (msg: Message) => {
                if (activeTabRef.current !== 'chat' && msg.senderId !== user.id) {
                    setUnreadCount(prev => prev + 1);
                    window.Telegram?.WebApp?.HapticFeedback?.notificationOccurred('success');
                }
            };

            socket.on('new_message', handleNewMessage);

            return () => {
                socket.off('new_message', handleNewMessage);
                // We leave project ONLY when completely leaving the page
                socket.emit('leave_project', { projectId });
            };
        }
    }, [projectId, user]);

    useEffect(() => {
        if (currentProject) {
            setEditForm({
                title: currentProject.title,
                description: currentProject.description || '',
                startDate: currentProject.startDate ? new Date(currentProject.startDate).toISOString().split('T')[0] : '',
                endDate: currentProject.endDate ? new Date(currentProject.endDate).toISOString().split('T')[0] : '',
            });
        }
    }, [currentProject]);

    const handleCopyInvite = () => {
        if (currentProject?.inviteCode) {
            navigator.clipboard.writeText(currentProject.inviteCode);
            window.Telegram?.WebApp?.HapticFeedback?.notificationOccurred('success');
        }
    };

    const handleDelete = async () => {
        if (projectId) {
            if (window.confirm('Вы уверены, что хотите удалить этот поход? Это действие нельзя отменить.')) {
                await deleteProject(projectId);
                navigate('/');
            }
        }
    };

    const handleUpdate = async () => {
        if (!projectId) return;
        try {
            await api.post(`/projects/${projectId}`, editForm);
            fetchProject(projectId);
            setShowEdit(false);
            window.Telegram?.WebApp?.HapticFeedback?.notificationOccurred('success');
        } catch (e) {
            console.error(e);
            window.Telegram?.WebApp?.HapticFeedback?.notificationOccurred('error');
        }
    };

    const handleCopyInviteLink = () => {
        if (!currentProject?.inviteCode) return;

        const link = `${window.location.origin}/join/${currentProject.inviteCode}`;
        const text = `Присоединяйся к моему походу «${currentProject.title}» в «Походном Сборщике»! 🏔\n\nСсылка для вступления: ${link}\nКод похода: ${currentProject.inviteCode}`;
        
        navigator.clipboard.writeText(text).then(() => {
            window.Telegram?.WebApp?.HapticFeedback?.notificationOccurred('success');
            alert('Ссылка-приглашение скопирована в буфер обмена!');
        });
    };

    if (!currentProject) return null;

    const isOwner = currentProject.ownerId === user?.id;

    const tabs = [
        { id: 'gear', label: 'Снаряжение', icon: Gear },
        { id: 'food', label: 'Еда', icon: ForkKnife },
        { id: 'checklist', label: 'Чек-лист', icon: CheckSquare },
        { id: 'medicine', label: 'Медицина', icon: FirstAid },
        { id: 'calendar', label: 'Календарь', icon: Calendar },
        { id: 'participants', label: 'Участники', icon: Users },
        { id: 'guide', label: 'Справочник', icon: BookBookmark },
        { id: 'diary', label: 'Дневник', icon: Notebook },
    ];

    return (
        <div className="min-h-screen pb-24 pt-4 px-4 space-y-4">
            {/* Header */}
            <div className="flex items-center justify-between mb-2">
                <button
                    onClick={() => navigate('/')}
                    className="p-2 -ml-2 rounded-full hover:bg-white/20 transition-colors text-[var(--text-primary)]"
                >
                    <ArrowLeft size={24} />
                </button>
                <div className="flex gap-2">
                    {isOwner && (
                        <>
                            <button
                                onClick={() => setShowEdit(true)}
                                className="p-2 rounded-full hover:bg-white/20 transition-colors text-[var(--text-primary)]"
                            >
                                <PencilSimple size={20} />
                            </button>
                            <button
                                onClick={handleDelete}
                                className="p-2 rounded-full hover:bg-white/20 transition-colors text-red-500 hover:text-red-400"
                            >
                                <Trash size={20} />
                            </button>
                        </>
                    )}
                    <button
                        onClick={() => setActiveTab('chat')}
                        className={`p-2 rounded-full backdrop-blur-md transition-colors relative flex items-center justify-center ${activeTab === 'chat' ? 'bg-[#2F80ED] text-white shadow-lg shadow-blue-500/30' : 'bg-white/20 text-[var(--text-primary)] hover:bg-white/30'}`}
                    >
                        <ChatTeardropText size={22} weight={activeTab === 'chat' ? 'fill' : 'duotone'} />
                        {unreadCount > 0 && (
                            <motion.div
                                initial={{ scale: 0 }}
                                animate={{ scale: 1 }}
                                className="absolute -top-1 -right-1"
                            >
                                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-red-400 opacity-75"></span>
                                <span className="relative flex h-[18px] min-w-[18px] px-1 items-center justify-center rounded-full bg-gradient-to-tr from-red-500 to-rose-400 text-[10px] font-bold text-white shadow-md ring-2 ring-white dark:ring-[#1c1c1e]">
                                    {unreadCount > 9 ? '9+' : unreadCount}
                                </span>
                            </motion.div>
                        )}
                    </button>
                    <button
                        onClick={handleCopyInviteLink}
                        className="p-2 rounded-full bg-white/20 backdrop-blur-md text-[var(--text-primary)] hover:bg-white/30 transition-colors"
                        title="Копировать приглашение"
                    >
                        <ShareNetwork size={20} weight="bold" />
                    </button>
                </div>
            </div>

            {/* Project Card */}
            <GlassCard className="p-6 relative overflow-hidden shadow-2xl">

                <div className="relative z-10">
                    <h1 className="text-3xl font-bold text-[var(--text-primary)] mb-2 tracking-tight">{currentProject.title}</h1>
                    {currentProject.description && (
                        <p className="text-sm text-[var(--text-secondary)] mb-4 line-clamp-2 leading-relaxed">
                            {currentProject.description}
                        </p>
                    )}

                    {currentProject.startDate && (
                        <div className="flex items-center gap-2 mb-4 text-[var(--text-secondary)] text-sm">
                            <div className="w-1 h-1 rounded-full bg-[var(--text-primary)] opacity-50" />
                            {new Date(currentProject.startDate).toLocaleDateString('ru-RU', { day: 'numeric', month: 'long' })}
                            {currentProject.endDate ? ` — ${new Date(currentProject.endDate).toLocaleDateString('ru-RU', { day: 'numeric', month: 'long' })}` : ''}
                        </div>
                    )}

                    <div className="flex flex-wrap gap-2 mb-5">
                        <Badge variant="outline" className="bg-white/50 dark:bg-white/10 border-white/40 dark:border-white/20 text-[var(--text-primary)] backdrop-blur-md">
                            {currentProject.type === 'hiking' ? '🥾 Пеший' : currentProject.type === 'ski' ? '⛷ Лыжный' : '🚣 Водный'}
                        </Badge>
                        <Badge variant="outline" className="bg-white/50 dark:bg-white/10 border-white/40 dark:border-white/20 text-[var(--text-primary)] backdrop-blur-md">
                            {currentProject.season === 'summer' ? '☀️ Лето' : currentProject.season === 'winter' ? '❄️ Зима' : currentProject.season === 'spring' ? '🌱 Весна' : '🍂 Осень'}
                        </Badge>
                    </div>

                    <div className="flex items-center gap-3 p-3 rounded-2xl bg-white/40 dark:bg-white/5 border border-white/20 dark:border-white/5 backdrop-blur-sm cursor-pointer active:scale-[0.98] transition-all" onClick={() => setActiveTab('participants')}>
                        <div className="flex -space-x-3">
                            {currentProject.members?.slice(0, 4).map((m) => (
                                <div key={m.id} className="w-9 h-9 rounded-full border-2 border-white dark:border-black/30 bg-gray-200 dark:bg-gray-600 flex items-center justify-center text-xs font-bold text-gray-700 dark:text-white overflow-hidden shadow-sm">
                                    {m.user.avatarUrl ? (
                                        <img src={m.user.avatarUrl} alt="" className="w-full h-full object-cover" />
                                    ) : (
                                        <span>{m.user.firstName?.[0] || m.user.username?.[0] || '?'}</span>
                                    )}
                                </div>
                            ))}
                            {(currentProject.members?.length || 0) > 4 && (
                                <div className="w-9 h-9 rounded-full border-2 border-white dark:border-black/30 bg-gray-100 dark:bg-gray-700 flex items-center justify-center text-xs font-medium text-gray-500 dark:text-white shadow-sm">
                                    +{currentProject.members!.length - 4}
                                </div>
                            )}
                        </div>
                        <div className="flex flex-col">
                            <span className="text-[10px] text-[var(--text-muted)] uppercase tracking-widest font-semibold">Участники</span>
                            <span className="text-xs text-[var(--text-primary)]">Нажмите, чтобы открыть</span>
                        </div>
                    </div>
                </div>
            </GlassCard>

            {/* Tabs */}
            <div className="flex overflow-x-auto pb-2 gap-2 hide-scrollbar">
                {tabs.map((tab) => (
                    <button
                        key={tab.id}
                        onClick={() => setActiveTab(tab.id as TabType)}
                        className={`
                            whitespace-nowrap px-4 py-2.5 text-sm font-semibold rounded-[14px] transition-all flex items-center gap-2
                            border
                            ${activeTab === tab.id
                                ? 'bg-white dark:bg-white/15 text-[var(--color-primary)] dark:text-white shadow-md border-transparent'
                                : 'bg-transparent border-transparent text-[var(--text-muted)] hover:text-[var(--text-primary)] hover:bg-white/10'
                            }
                        `}
                    >
                        <tab.icon size={18} weight={activeTab === tab.id ? 'fill' : 'regular'} />
                        {tab.label}
                    </button>
                ))}
            </div>

            {/* Tab Content */}
            <AnimatePresence mode="wait">
                <motion.div
                    key={activeTab}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    transition={{ duration: 0.2 }}
                >
                    {activeTab === 'gear' && <GearTab />}
                    {activeTab === 'food' && <FoodTab />}
                    {activeTab === 'checklist' && <ChecklistTab />}
                    {activeTab === 'chat' && <ChatTab />}
                    {activeTab === 'calendar' && <CalendarTab />}
                    {activeTab === 'participants' && <ParticipantsTab />}
                    {activeTab === 'guide' && <GuideTab />}
                    {activeTab === 'diary' && <DiaryTab />}
                    {activeTab === 'medicine' && <MedicineTab />}
                </motion.div>
            </AnimatePresence>

            {/* Edit Modal */}
            <AnimatePresence>
                {showEdit && (
                    <motion.div
                        initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                        className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4 backdrop-blur-sm"
                        onClick={() => setShowEdit(false)}
                    >
                        <motion.div
                            initial={{ scale: 0.95 }} animate={{ scale: 1 }} exit={{ scale: 0.95 }}
                            className="bg-white dark:bg-[#1c1c1e] w-full max-w-md rounded-2xl p-6 shadow-2xl border border-white/10"
                            onClick={e => e.stopPropagation()}
                        >
                            <h2 className="text-xl font-bold text-[var(--text-primary)] mb-4">Редактировать поход</h2>
                            <div className="space-y-4">
                                <div>
                                    <label className="text-xs text-[var(--text-secondary)] mb-1 block">Название</label>
                                    <input
                                        type="text"
                                        className="w-full bg-gray-100 dark:bg-white/5 border-none rounded-xl p-3 text-[var(--text-primary)] outline-none focus:ring-2 focus:ring-[#2F80ED]"
                                        value={editForm.title}
                                        onChange={e => setEditForm({ ...editForm, title: e.target.value })}
                                    />
                                </div>
                                <div>
                                    <label className="text-xs text-[var(--text-secondary)] mb-1 block">Описание</label>
                                    <textarea
                                        className="w-full bg-gray-100 dark:bg-white/5 border-none rounded-xl p-3 text-[var(--text-primary)] outline-none focus:ring-2 focus:ring-[#2F80ED] h-24 resize-none"
                                        value={editForm.description}
                                        onChange={e => setEditForm({ ...editForm, description: e.target.value })}
                                    />
                                </div>
                                <div className="grid grid-cols-2 gap-4">
                                    <div>
                                        <label className="text-xs text-[var(--text-secondary)] mb-1 block">Дата начала</label>
                                        <input
                                            type="date"
                                            className="w-full bg-gray-100 dark:bg-white/5 border-none rounded-xl p-3 text-[var(--text-primary)] outline-none focus:ring-2 focus:ring-[#2F80ED]"
                                            value={editForm.startDate}
                                            onChange={e => setEditForm({ ...editForm, startDate: e.target.value })}
                                        />
                                    </div>
                                    <div>
                                        <label className="text-xs text-[var(--text-secondary)] mb-1 block">Дата конца</label>
                                        <input
                                            type="date"
                                            className="w-full bg-gray-100 dark:bg-white/5 border-none rounded-xl p-3 text-[var(--text-primary)] outline-none focus:ring-2 focus:ring-[#2F80ED]"
                                            value={editForm.endDate}
                                            onChange={e => setEditForm({ ...editForm, endDate: e.target.value })}
                                        />
                                    </div>
                                </div>
                                <div className="flex gap-3 pt-2">
                                    <Button variant="secondary" className="flex-1" onClick={() => setShowEdit(false)}>Отмена</Button>
                                    <Button className="flex-1 bg-[#2F80ED] text-white" onClick={handleUpdate}>Сохранить</Button>
                                </div>
                            </div>
                        </motion.div>
                    </motion.div>
                )}
            </AnimatePresence>
        </div>
    );
}
