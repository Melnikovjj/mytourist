import React from 'react';
import { motion, HTMLMotionProps } from 'motion/react';
import { cn } from './GlassCard';

interface ButtonProps extends HTMLMotionProps<"button"> {
  variant?: 'primary' | 'secondary' | 'glass' | 'ghost';
  size?: 'sm' | 'md' | 'lg' | 'icon';
  isLoading?: boolean;
}

export const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant = 'primary', size = 'md', isLoading, children, ...props }, ref) => {
    
    const variants = {
      primary: 'bg-gradient-to-r from-[#4AC7FA] to-[#2F80ED] text-white shadow-[0_4px_15px_rgba(47,128,237,0.3)] border-transparent hover:shadow-[0_6px_20px_rgba(47,128,237,0.4)]',
      secondary: 'bg-white/80 text-[#1C1C1E] border border-white/40 shadow-sm hover:bg-white/90',
      glass: 'bg-white/40 backdrop-blur-md border border-white/50 text-[#1C1C1E] shadow-sm hover:bg-white/50',
      ghost: 'bg-transparent text-[#1C1C1E] hover:bg-white/20',
    };

    const sizes = {
      sm: 'h-9 px-4 text-sm rounded-xl',
      md: 'h-12 px-6 text-base rounded-2xl',
      lg: 'h-[56px] px-8 text-lg font-medium rounded-[20px]',
      icon: 'h-10 w-10 p-2 rounded-full flex items-center justify-center',
    };

    return (
      <motion.button
        ref={ref}
        whileTap={{ scale: 0.96 }}
        className={cn(
          'inline-flex items-center justify-center font-medium transition-all focus:outline-none disabled:opacity-50 disabled:pointer-events-none',
          variants[variant],
          sizes[size],
          className
        )}
        {...props}
      >
        {isLoading ? (
          <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin mr-2" />
        ) : null}
        {children}
      </motion.button>
    );
  }
);
Button.displayName = "Button";
