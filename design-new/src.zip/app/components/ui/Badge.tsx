import React from 'react';
import { cn } from './GlassCard';

interface BadgeProps {
  status: 'success' | 'warning' | 'error' | 'neutral' | 'info';
  children: React.ReactNode;
  className?: string;
}

export const Badge: React.FC<BadgeProps> = ({ status, children, className }) => {
  const styles = {
    success: 'bg-[#34C759]/15 text-[#34C759] border-[#34C759]/20',
    warning: 'bg-[#FF9F0A]/15 text-[#FF9F0A] border-[#FF9F0A]/20',
    error: 'bg-[#FF3B30]/15 text-[#FF3B30] border-[#FF3B30]/20',
    neutral: 'bg-gray-500/15 text-gray-600 border-gray-500/20',
    info: 'bg-[#2F80ED]/15 text-[#2F80ED] border-[#2F80ED]/20',
  };

  return (
    <span className={cn(
      'inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold border backdrop-blur-sm',
      styles[status],
      className
    )}>
      {children}
    </span>
  );
};
