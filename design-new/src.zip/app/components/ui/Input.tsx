import React from 'react';
import { cn } from './GlassCard';

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
}

export const Input = React.forwardRef<HTMLInputElement, InputProps>(
  ({ className, label, error, ...props }, ref) => {
    return (
      <div className="w-full space-y-1.5">
        {label && (
          <label className="text-sm font-medium text-[#1C1C1E]/70 ml-1">
            {label}
          </label>
        )}
        <input
          ref={ref}
          className={cn(
            'w-full px-4 py-3 bg-white/40 border border-white/40 rounded-2xl text-[#1C1C1E] placeholder:text-gray-400/80 outline-none transition-all',
            'focus:bg-white/60 focus:border-[#2F80ED]/50 focus:ring-2 focus:ring-[#2F80ED]/20',
            'disabled:opacity-50 disabled:cursor-not-allowed',
            error && 'border-red-500/50 focus:border-red-500/50 focus:ring-red-500/20',
            className
          )}
          {...props}
        />
        {error && (
          <p className="text-xs text-red-500 ml-1">{error}</p>
        )}
      </div>
    );
  }
);
Input.displayName = "Input";
