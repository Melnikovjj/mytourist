import React from 'react';
import { cn } from './GlassCard';

interface AvatarProps {
  src?: string;
  alt?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  glow?: boolean;
  className?: string;
  fallback?: string;
}

export const Avatar: React.FC<AvatarProps> = ({ 
  src, 
  alt = "User", 
  size = 'md', 
  glow = false, 
  className,
  fallback = "U"
}) => {
  const sizes = {
    sm: 'w-8 h-8 text-xs',
    md: 'w-10 h-10 text-sm',
    lg: 'w-14 h-14 text-base',
    xl: 'w-20 h-20 text-xl',
  };

  return (
    <div className={cn('relative inline-block', className)}>
      <div 
        className={cn(
          'rounded-full overflow-hidden border-2 border-white/50 bg-gray-200 flex items-center justify-center text-gray-500 font-medium',
          sizes[size],
          glow && 'shadow-[0_0_15px_rgba(47,128,237,0.4)] ring-2 ring-[#2F80ED]/20'
        )}
      >
        {src ? (
          <img src={src} alt={alt} className="w-full h-full object-cover" />
        ) : (
          <span>{fallback}</span>
        )}
      </div>
      {glow && (
        <div className="absolute inset-0 rounded-full bg-[#2F80ED] opacity-10 blur-md -z-10 animate-pulse" />
      )}
    </div>
  );
};
